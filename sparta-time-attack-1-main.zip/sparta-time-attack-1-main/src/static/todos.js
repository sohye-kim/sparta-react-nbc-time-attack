export const defaultTodos = [
  {
    id: 1,
    title: "Let's Time Attack!",
    content: "Solve the First Problem!",
    completed: false,
    limit: "2024-02-06",
  },
  {
    id: 2,
    title: "Let's Time Attack!",
    content: "Solve the Second Problem!",
    completed: false,
    limit: "2024-02-06",
  },
  {
    id: 3,
    title: "Let's Time Attack!",
    content: "Solve the Third Problem!",
    completed: false,
    limit: "2024-02-06",
  },
];
