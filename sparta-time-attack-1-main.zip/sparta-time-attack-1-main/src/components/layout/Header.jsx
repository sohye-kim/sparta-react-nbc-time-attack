import { TodoHeader } from "../../style/TodoStyle";

const Header = () => {
  return (
    <TodoHeader>
      <h1>My todo list</h1>
      <h1>React</h1>
    </TodoHeader>
  );
};

export default Header;
